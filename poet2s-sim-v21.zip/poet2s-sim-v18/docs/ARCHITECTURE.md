# Architecture

Design notes for the PoET²S simulator. Read after `README.md`.

## Layer separation

Three layers, each in its own module:

```
┌──────────────────────────────────────────────────────────┐
│  detection.py — per-slot loop (run_protocol_slots)       │
│    physics tick → forecast → attacks → consensus → trust │
└──────────────────────────────────────────────────────────┘
              │                                  │
              ▼                                  ▼
┌──────────────────────────────┐   ┌──────────────────────┐
│  protocols.py — state machines│   │  grid_model.py       │
│    PoW, PoS, PBFT, DPoS,     │   │    GridNode, twin,    │
│    +Twin variants, PoET²S    │   │    apply_attacks      │
└──────────────────────────────┘   └──────────────────────┘
              │
              ▼
┌──────────────────────────────────────────────────────────┐
│  sim_core.py — DEScheduler + Network                     │
│    priority-queue events, Pareto RTT, bandwidth queues   │
└──────────────────────────────────────────────────────────┘
```

Each layer depends only on the ones below it. Consensus protocols see the network but not the grid; the grid layer knows nothing about consensus messages. This separation is what makes the system extensible: adding a protocol does not touch the grid, and adding an attack does not touch any consensus code.

## Discrete-event scheduler

`DEScheduler` is a single-threaded priority-queue event loop. Time is a floating-point millisecond, advanced by `heapq.heappop`. There is no real-time clock; "wall-clock latency" in the paper refers to the simulated `now_ms`.

Events are stable-ordered: when two events have the same time, the one scheduled first runs first. This matters for protocol determinism — a flaky tie-break would make seed-replication unreliable.

`run_until(horizon)` runs every event up to `horizon` and stops; `drain()` runs every pending event regardless of time. Protocols typically call `run_until` after `propose_block` to bound simulation effort per round.

## Network model

`Network` is event-driven, not packet-level. For each `send(msg)`:

1. **Bandwidth queue**: outbound transmit time is `8 × size_bytes / B` (B = 50 Mbit/s by default). Per-node `next_send_time[src]` tracks when the queue empties; a new message starts no earlier than this.
2. **Propagation**: one-way delay is drawn per send from `Pareto(α=2, x_m=10 ms) / 2`, giving median ≈ 14 ms, mean ≈ 20 ms, and a heavy upper tail. The Pareto choice matches measurements of public P2P overlays where middle-mile congestion produces long-tail latencies.
3. **Processing**: receiver pays a fixed 0.05 ms verify cost on delivery.

`broadcast` and `multicast` are macros over `send`. Both exclude the sender by design — a protocol that needs to count "self" must add the sender to its accumulator explicitly. This is the source of the `sent_commit` tracking in PBFT and PoET²S: every validator must independently realise it has crossed the prepare threshold and broadcast a commit.

## Protocol state machines

Each protocol subclasses `ConsensusBase`. The interface is minimal:

- `propose_block() -> int` — start one consensus round, return the block id.
- `on_finalised` — optional callback invoked when a block commits.
- `blocks: Dict[int, BlockRecord]` — per-block start/commit times for latency measurement.

Inside, a protocol registers message handlers with the network and uses the scheduler to enforce per-message processing delays (`COMPUTE_MS_PER_MSG`, `SIGN_MS`).

### PoW

Single block proposer drawn uniformly. Time-to-block is exponential with mean 8 s (configurable). After the block is found, a broadcast goes to all N peers. Latency = exponential wait + max propagation.

### PoS

Stake-weighted proposer; stake-weighted committee of C = 16 nodes attests. Block commits when ⌈2C/3⌉ = 11 attestations reach the proposer. Two-message round-trip; latency ≈ 1 RTT plus signing.

### PBFT

Full Castro–Liskov three-phase commit on V = 15 % of N validators. Pre-prepare from primary; prepare and commit phases each cost V² messages and require ⌈2V/3⌉ to fire. Total messages per block: ≈ 3V². Latency stays small as long as the per-node bandwidth absorbs V² messages; at N = 2,000 (V = 300) bandwidth saturation extends latency to 47 ms.

### DPoS

Top-7 stake holders rotate as proposer. Single message round to 4-of-7 ack. Constant time and constant messages, regardless of N.

### PoET²S

The protocol of interest. Three differences from PBFT:

1. The validator set is the top-K = 21 nodes by weight `W_i = (ω_s · s_i + ω_e · (e_i + 1)) · TTS_i^γ`, where stake `s_i`, energy contribution `e_i`, and twin-trust score `TTS_i` are all per-node state. The exponent γ = 2.5 makes trust deficit punishing — a node at TTS = 0.5 has weight 0.5^2.5 ≈ 0.18 of an honest node with the same stake.

2. The proposer is drawn within the committee with probability proportional to W_i, not chosen round-robin.

3. After every slot, every sampled node's TTS updates by EWMA from the twin's anomaly score, so a sustained liar fades out of the committee within ~10 slots.

The Sybil-resistance bound (Theorem 1 in the paper) is what makes the trust mechanism cost an attacker not just one block of false reports but the entire economic stake-weighted opportunity for future blocks too.

### +Twin variants

PoS+Twin, PBFT+Twin, DPoS+Twin use the baseline consensus mechanics unchanged but OR the twin's anomaly score onto the baseline's peer-median detector. They are ablations: they isolate the "twin as veto" contribution from the "twin in validator weight" contribution. PoET²S has both; the +Twin baselines have only the first.

## Grid model

`GridNode` carries stake, role (prosumer/consumer/validator), PV capacity, base demand, honesty flag, attack type, trust score, and the two report/actual pairs. Profiles are sampled from public dataset statistics (Pecan Street Dataport for PV and load; UMass Smart\* for variance) so an external reviewer can replicate the calibration.

`apply_attacks` is the adversarial layer: it walks the malicious nodes and writes false `reported_*` values without touching `actual_*`. The twin sees only reported values; the protocol sees the same. Ground truth is used only to score detection outcomes.

## Digital twin

The twin's job is one number per node per slot: σ ∈ [0, 1]. Higher means more anomalous.

`forecast` blends a closed-form solar/load physics envelope with the EWMA of the node's last 50 *reported* values. The 0.65/0.35 split is intentional: a sustained liar can pull the EWMA but not the physics envelope, so the floor of σ stays well above zero for a node whose lies persist.

`verify` produces the deviation `δ` from forecast and passes it through a logistic dead-band `σ = 1 / (1 + exp(−κ(δ − τ)))` with τ = 0.35 and κ = 6. The dead-band absorbs honest measurement noise; the steep slope makes σ resolve quickly once δ crosses the threshold.

`record` is the F4 fix: history is populated with REPORTED values, never with ground truth. Earlier internal versions of this code had a subtle bug where ground truth leaked into history, making the twin omniscient. The current implementation is faithful to what a real twin can observe.

## Detection layer

`run_protocol_slots` is the per-slot loop. For each slot t:

1. Physics: `twin.tick`, `sample_slot` produces actual generation/demand.
2. Forecast for a 150-node sample (proposer + random 149).
3. `apply_attacks` writes adversarial reports.
4. Detector decides per node `(honest, flagged)` and per protocol whether the twin OR-flag fires.
5. `proto.update_trust(node)` for PoET²S (no-op for baselines).
6. `proto.propose_block()` starts consensus; `sched.run_until(now + 120000)` lets it finalise.

The detector is mechanistic: each baseline has a deviation threshold (60 % for PoS, 40 % for PBFT, 50 % for DPoS) against the sample-median report. PoET²S uses the twin's σ > 0.35. +Twin variants OR the two.

The 150-node sample size is deliberate: it gives every scheme the same per-slot fairness budget so that scheme comparisons are not confounded by different sampling rates.

## Determinism and reproducibility

Three RNG streams: one for grid construction, one for the network's Pareto draws, one for protocol proposer/committee selection. All three are seeded from a single integer in the test harness. `test_deterministic_across_runs` asserts that two runs with the same seed produce bit-identical latencies.

This determinism is the property that lets `summary_v15.csv` be a static commit in the repository: anyone who runs `scripts/run_main.py` will reproduce it exactly.

## Threading and scaling

The simulator is single-threaded. All concurrency is logical (events). At N = 500 the full 10-seed × 8-scheme × 60-slot sweep finishes in about 2.5 minutes on a 2020-era laptop. At N = 5,000 PBFT-family schemes dominate — the V² message count makes them ~30 minutes per seed. The current code is fast enough for the paper's N = 500 main experiment but would benefit from per-seed parallelisation (trivial: each seed is independent) for larger sweeps.

## What is intentionally out of scope

- Packet-level transport. No TCP/UDP, no congestion control, no MAC.
- Cryptographic detail. Signatures are accounted as fixed-cost ms, not as actual ed25519 primitives.
- View changes for PBFT. We assume the primary stays up for the run.
- Compromised twins. The threat model puts the twin in a trusted execution environment.

A reviewer who wants any of these can extend the layers above incrementally without rewriting the core.
