"""Flag every number in the manuscript that is neither a model constant nor a value derivable from the result CSVs."""
import csv, glob, re, sys, itertools
sys.path.insert(0, '/home/claude/rev')
import importlib, content as C
importlib.reload(C)
RES = '/home/claude/poet2s-sim-v18/results/'
vals = set()
def add(x):
    try: x = float(x)
    except: return
    for nd in (0, 1, 2, 3):
        vals.add(round(x, nd)); vals.add(round(abs(x), nd))
        vals.add(round(100 * x, nd))
for f in glob.glob(RES + '*.csv'):
    rows = list(csv.DictReader(open(f)))
    for r in rows:
        for v in r.values(): add(v)
    # group means / sds by first string column(s)
    if not rows: continue
    keys = [k for k in rows[0] if not re.fullmatch(r'-?[\d.e+-]+|nan|True|False', rows[0][k] or 'x')]
    num = [k for k in rows[0] if k not in keys]
    import collections, statistics as st
    for kset in [keys[:1], keys[:2], keys[:3], keys]:
        g = collections.defaultdict(list)
        for r in rows: g[tuple(r[k] for k in kset)].append(r)
        for sub in g.values():
            for m in num:
                xs = []
                for r in sub:
                    try:
                        v = float(r[m])
                        if v == v: xs.append(v)
                    except: pass
                if xs:
                    add(st.mean(xs)); add(st.median(xs))
                    if len(xs) > 1: add(st.stdev(xs))
                    add(min(xs)); add(max(xs)); add(sum(xs))
CONST = {0.65,0.35,0.55,0.45,6,0.3,0.22,0.01,1,0.2,1.2,6.5,2.8,1.3,0.4,0.85,13,19,21,14,17,4,5,3,0.5,2.5,16,11,7,8,12,
         150,0.6,0.1,0.05,10,50,256,1024,120,250,30,42,71,100,141,60,500,4000,2000,1000,15,45,0.75,0.25,0.15,1.0,
         2.0,1.6,2.4,3.2,0.08,0.18,1.08,1.18,1.25,1.1,1.5,36,72,9,0.02,1326,5000,35,20,2,0.7,0.8,0.9,0.95}
TAG = re.compile(r'</?(i|b|sub|sup)>')
texts = []
for b in C.B:
    if b[0] in ('p','li','h1','h2'): texts.append(b[-1])
    elif b[0] == 'fig': texts.append(b[2])
    elif b[0] == 'tab':
        texts.append(b[1])
        if isinstance(b[3], list): texts += [c for r in b[3] for c in r]
texts.append(C.ABSTRACT)
unmatched = []
for t in texts:
    t = re.sub(r'\[@[^\]]+\]', '', TAG.sub('', t)).replace('−','-').replace(',', '')
    for m in re.finditer(r'(?<![\w.])-?\d+(?:\.\d+)?', t):
        s = m.group(); x = float(s)
        nd = len(s.split('.')[1]) if '.' in s else 0
        ok = x in CONST or round(x, nd) in vals or any(abs(v - x) < 0.5 * 10 ** -nd + 1e-9 for v in vals if abs(v - x) < 1)
        if not ok:
            unmatched.append((s, t[max(0, m.start()-60):m.end()+40]))
print(len(unmatched), 'numbers not directly found in results or constants:')
for s, ctx in unmatched: print(f'  {s:>8}  …{ctx}…')
