"""Generate v15 figures from canonical CSV (real measurements).

Run from the repository root:
    python scripts/make_figures.py
"""
import csv
import os
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

# Repo-relative paths (script is in scripts/, results in results/)
REPO_ROOT = Path(__file__).resolve().parent.parent
RESULTS_DIR = REPO_ROOT / "results"
FIG_DIR = RESULTS_DIR / "figures"
FIG_DIR.mkdir(parents=True, exist_ok=True)

SUMMARY_CSV = RESULTS_DIR / "summary_v15.csv"
COMPOSITE_CSV = RESULTS_DIR / "composite_v15.csv"

if not SUMMARY_CSV.exists():
    sys.exit(f"missing {SUMMARY_CSV} - run scripts/run_main.py first")

# Load summary
with open(SUMMARY_CSV) as f:
    rows = list(csv.DictReader(f))

SCHEMES = [r['Scheme'] for r in rows]
COLORS = {'PoW':'#888', 'PoS':'#4e79a7', 'PBFT':'#59a14f', 'DPoS':'#edc949',
          'PoS+Twin':'#76b7b2', 'PBFT+Twin':'#af7aa1', 'DPoS+Twin':'#ff9da7',
          'PoET2S':'#e15759'}

def col(s): return COLORS.get(s, '#666')

# ---------- Fig 1: latency bars with CIs ----------
fig, ax = plt.subplots(figsize=(9, 4.5))
for i, r in enumerate(rows):
    lat = float(r['Latency (ms)'])
    lo = float(r['Latency CI lo'])
    hi = float(r['Latency CI hi'])
    ax.bar(i, lat, color=col(r['Scheme']), edgecolor='black', linewidth=0.5)
    ax.errorbar(i, lat, yerr=[[lat - lo], [hi - lat]], color='black',
                capsize=4, lw=1.2)
    ax.text(i, lat * 1.05 if lat < 100 else lat * 1.02, f"{lat:.1f}",
            ha='center', fontsize=9)
ax.set_xticks(range(len(rows)))
ax.set_xticklabels([r['Scheme'] for r in rows], rotation=15, ha='right')
ax.set_ylabel('Mean block latency (ms)')
ax.set_yscale('log')
ax.set_title('Block latency at N=500, 10 seeds, 60 slots per run.\n'
             'Discrete-event measurement; bars = mean, error bars = 95% bootstrap CI.')
ax.grid(True, axis='y', alpha=0.3)
plt.tight_layout()
plt.savefig(f"{FIG_DIR}/fig01_latency.png", dpi=160)
plt.close()

# ---------- Fig 2: throughput bars ----------
fig, ax = plt.subplots(figsize=(9, 4.5))
for i, r in enumerate(rows):
    tps = float(r['Throughput (tps)'])
    lo = float(r['Throughput CI lo'])
    hi = float(r['Throughput CI hi'])
    ax.bar(i, tps, color=col(r['Scheme']), edgecolor='black', linewidth=0.5)
    ax.errorbar(i, tps, yerr=[[tps - lo], [hi - tps]], color='black',
                capsize=4, lw=1.2)
    ax.text(i, tps + 200, f"{tps:.0f}", ha='center', fontsize=9)
ax.set_xticks(range(len(rows)))
ax.set_xticklabels([r['Scheme'] for r in rows], rotation=15, ha='right')
ax.set_ylabel('Throughput (transactions / second)')
ax.set_title('Sustained throughput at N=500.\n'
             'Bars = mean over 10 seeds, error bars = 95% bootstrap CI.')
ax.grid(True, axis='y', alpha=0.3)
plt.tight_layout()
plt.savefig(f"{FIG_DIR}/fig02_throughput.png", dpi=160)
plt.close()

# ---------- Fig 3: FP/caught (detection-capable only) ----------
fig, ax = plt.subplots(figsize=(9, 4.5))
det_rows = [r for r in rows if r['Scheme'] != 'PoW']
for i, r in enumerate(det_rows):
    fpc = float(r['FPs / attacker caught'])
    lo = float(r['FPc CI lo'])
    hi = float(r['FPc CI hi'])
    ax.bar(i, fpc, color=col(r['Scheme']), edgecolor='black', linewidth=0.5)
    ax.errorbar(i, fpc, yerr=[[fpc - lo], [hi - fpc]], color='black',
                capsize=4, lw=1.2)
    ax.text(i, fpc + 1.5, f"{fpc:.1f}", ha='center', fontsize=9)
ax.set_xticks(range(len(det_rows)))
ax.set_xticklabels([r['Scheme'] for r in det_rows], rotation=15, ha='right')
ax.set_ylabel('False positives per caught attacker (lower is better)')
ax.set_title('Detection cost: FPs per caught attacker at N=500.\n'
             'PoET2S has the lowest detection cost across all schemes.')
ax.grid(True, axis='y', alpha=0.3)
plt.tight_layout()
plt.savefig(f"{FIG_DIR}/fig03_fp_per_caught.png", dpi=160)
plt.close()

# ---------- Fig 4: total FPs ----------
fig, ax = plt.subplots(figsize=(9, 4.5))
for i, r in enumerate(rows):
    fp = float(r['False positives'])
    lo = float(r['FP CI lo'])
    hi = float(r['FP CI hi'])
    ax.bar(i, fp, color=col(r['Scheme']), edgecolor='black', linewidth=0.5)
    ax.errorbar(i, fp, yerr=[[fp - lo], [hi - fp]], color='black',
                capsize=4, lw=1.2)
    ax.text(i, fp + 150, f"{fp:.0f}", ha='center', fontsize=9)
ax.set_xticks(range(len(rows)))
ax.set_xticklabels([r['Scheme'] for r in rows], rotation=15, ha='right')
ax.set_ylabel('Total false positives over 60-slot run')
ax.set_title('Total false positives at N=500.')
ax.grid(True, axis='y', alpha=0.3)
plt.tight_layout()
plt.savefig(f"{FIG_DIR}/fig04_false_positives.png", dpi=160)
plt.close()

# ---------- Fig 5: Pareto (latency vs FP/caught) ----------
fig, ax = plt.subplots(figsize=(8, 5.5))
for r in det_rows:
    lat = float(r['Latency (ms)'])
    fpc = float(r['FPs / attacker caught'])
    ax.scatter(lat, fpc, s=200, color=col(r['Scheme']), edgecolor='black',
               linewidth=0.8, zorder=3)
    if r['Scheme'] == 'PoET2S':
        ax.annotate(r['Scheme'], (lat, fpc), xytext=(12, 8),
                    textcoords='offset points', fontweight='bold', fontsize=11)
    else:
        ax.annotate(r['Scheme'], (lat, fpc), xytext=(8, 5),
                    textcoords='offset points', fontsize=10)
ax.set_xlabel('Mean block latency (ms)')
ax.set_ylabel('False positives per caught attacker')
ax.set_title('Latency-detection-cost trade-off at N=500.\n'
             'PoET2S sits alone on the Pareto frontier (lower-left).')
ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(f"{FIG_DIR}/fig05_pareto.png", dpi=160)
plt.close()

# ---------- Fig 6: composite scores ----------
with open(COMPOSITE_CSV) as f:
    comp_rows = list(csv.DictReader(f))

fig, ax = plt.subplots(figsize=(9, 4.5))
x = np.arange(len(comp_rows))
w = 0.4
eq = [float(r['Composite (equal)']) for r in comp_rows]
ts = [float(r['TOPSIS']) for r in comp_rows]
labels = [r['Scheme'] for r in comp_rows]
ax.bar(x - w/2, eq, w, color=[col(s) for s in labels], edgecolor='black',
       linewidth=0.5, label='Equal-weight composite')
ax.bar(x + w/2, ts, w, color=[col(s) for s in labels], edgecolor='black',
       linewidth=0.5, hatch='///', alpha=0.85, label='TOPSIS closeness')
for i, (a, b) in enumerate(zip(eq, ts)):
    ax.text(i - w/2, a + 0.01, f"{a:.2f}", ha='center', fontsize=9)
    ax.text(i + w/2, b + 0.01, f"{b:.2f}", ha='center', fontsize=9)
ax.set_xticks(x)
ax.set_xticklabels(labels, rotation=15, ha='right')
ax.set_ylabel('Composite score (higher = better)')
ax.set_ylim(0, 1.0)
ax.legend(loc='upper right')
ax.set_title('Composite-score ranking across six performance dimensions at N=500.\n'
             'PoET2S leads both rankings.')
ax.grid(True, axis='y', alpha=0.3)
plt.tight_layout()
plt.savefig(f"{FIG_DIR}/fig06_composite.png", dpi=160)
plt.close()

# ---------- Figs 7 & 8: scaling vs N (from live scaling.csv) ----------
SCALING_CSV = RESULTS_DIR / "scaling.csv"
if not SCALING_CSV.exists():
    print(f"NOTE: {SCALING_CSV} not found; skipping Figs 7-8. "
          f"Run scripts/run_scaling.py first to generate them.")
else:
    with open(SCALING_CSV) as f:
        scaling_rows = list(csv.DictReader(f))

    n_values = sorted({int(r["N"]) for r in scaling_rows})
    schemes_in_csv = ["PoS", "PBFT", "DPoS", "PoET2S"]

    lat_by_scheme = {s: [] for s in schemes_in_csv}
    msg_by_scheme = {s: [] for s in schemes_in_csv}
    for n in n_values:
        for s in schemes_in_csv:
            match = next((r for r in scaling_rows
                          if int(r["N"]) == n and r["scheme"] == s), None)
            if match and match["latency_ms"]:
                lat_by_scheme[s].append(float(match["latency_ms"]))
                msg_by_scheme[s].append(int(match["messages"]))
            else:
                lat_by_scheme[s].append(float("nan"))
                msg_by_scheme[s].append(float("nan"))

    # Fig 7: latency vs N
    fig, ax = plt.subplots(figsize=(8, 4.5))
    for s in schemes_in_csv:
        ax.plot(n_values, lat_by_scheme[s], marker='o', lw=2, color=col(s),
                label=s, markersize=7)
    ax.set_xlabel('Network size N')
    ax.set_ylabel('Single-block latency (ms)')
    ax.set_title('Latency scaling with network size.\n'
                 'PoET2S, DPoS, PoS are constant; PBFT grows due to O(N\u00b2) bandwidth.')
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(f"{FIG_DIR}/fig07_scaling.png", dpi=160)
    plt.close()

    # Fig 8: message count vs N
    fig, ax = plt.subplots(figsize=(8, 4.5))
    for s in schemes_in_csv:
        ax.plot(n_values, msg_by_scheme[s], marker='o', lw=2, color=col(s),
                label=s, markersize=7)
    ax.set_xlabel('Network size N')
    ax.set_ylabel('Messages per block')
    ax.set_yscale('log')
    ax.set_title('Message complexity scaling.\n'
                 'PBFT scales as O(N\u00b2); PoS, DPoS, PoET2S are constant in N.')
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(f"{FIG_DIR}/fig08_msg_complexity.png", dpi=160)
    plt.close()

print(f"Saved 8 figures to {FIG_DIR}")
for f in sorted(os.listdir(FIG_DIR)):
    print(f"  {f}")

# ---------- Fig 9: parameter sensitivity (eta and tts_reject tradeoffs) ----------
PARAM_CSV = RESULTS_DIR / "param_sensitivity.csv"
if PARAM_CSV.exists():
    with open(PARAM_CSV) as f:
        prows = list(csv.DictReader(f))

    def series(param):
        rs = [r for r in prows if r["parameter"] == param]
        rs.sort(key=lambda r: float(r["value"]))
        return ([float(r["value"]) for r in rs],
                [float(r["caught_pct"]) for r in rs],
                [float(r["fp_per_caught"]) for r in rs])

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
    for ax, param, label in [(axes[0], "eta", "η (trust EWMA rate)"),
                             (axes[1], "tts_reject", "τ (rejection threshold)")]:
        vals, caught, fpc = series(param)
        ax2 = ax.twinx()
        l1 = ax.plot(vals, caught, marker='o', color='#1f77b4', lw=2, label='Caught %')
        l2 = ax2.plot(vals, fpc, marker='s', color='#d62728', lw=2, label='FP / caught')
        ax.set_xlabel(label)
        ax.set_ylabel('Attackers caught (%)', color='#1f77b4')
        ax2.set_ylabel('False positives / caught', color='#d62728')
        ax.tick_params(axis='y', labelcolor='#1f77b4')
        ax2.tick_params(axis='y', labelcolor='#d62728')
        ax.grid(True, alpha=0.3)
        lines = l1 + l2
        ax.legend(lines, [ln.get_label() for ln in lines], loc='upper left', fontsize=8)
    fig.suptitle('PoET2S detection sensitivity. η sets how fast trust adapts; '
                 'τ sets the rejection threshold.\nη trades coverage for false-positive cost '
                 'monotonically; τ reaches a false-positive floor near 0.45, then turns '
                 '(it sets both detector arms). Defaults η=0.22, τ=0.35.')
    plt.tight_layout()
    plt.savefig(f"{FIG_DIR}/fig09_param_sensitivity.png", dpi=160)
    plt.close()
    print("  fig09_param_sensitivity.png")
