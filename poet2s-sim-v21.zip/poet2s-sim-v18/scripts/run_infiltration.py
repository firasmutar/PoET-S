"""Committee-infiltration experiment: twin-in-formula vs twin-as-veto.

This is the experiment that isolates PoET2S's central design choice. Both
PoET2S and the PoMonitor competitor use a K-node committee and an identical
three-phase commit; they differ ONLY in how the twin enters validator
selection:

  - PoMonitor (twin-as-veto): binary gate. A node is excluded only if its
    instantaneous twin score crosses a veto threshold; otherwise it keeps full
    stake+energy selection weight.
  - PoET2S (twin-in-formula): the Twin-Trust Score enters the selection weight
    continuously as TTS^gamma, so a borderline node is smoothly down-weighted
    even when it never crosses any single threshold.

We measure the malicious share of committee seats over the run - the fraction
of validating-committee slots held by Byzantine nodes. Lower is better: it
means the consensus core is harder for an adversary to infiltrate.

Run from the repository root:
    python scripts/run_infiltration.py
"""
from __future__ import annotations

import csv
import random
import statistics
import sys
from pathlib import Path

import numpy as np

from poet2s_sim.grid_model import (
    DigitalTwin,
    apply_attacks,
    build_grid,
    sample_slot,
)
from poet2s_sim.protocols import PoET2S, PoMonitor
from poet2s_sim.sim_core import DEScheduler, Network

REPO_ROOT = Path(__file__).resolve().parent.parent
RESULTS_DIR = REPO_ROOT / "results"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_CSV = RESULTS_DIR / "infiltration.csv"

N = 500
N_SLOTS = 60
SEEDS = list(range(42, 52))   # 10 seeds


def infiltration_share(cls, seed: int, adaptive: bool = False) -> float:
    """Mean malicious committee share (%) over the run for one seed."""
    rng = random.Random(seed)
    nodes = build_grid(N, 0.15, rng, adaptive=adaptive)
    np_rng = np.random.default_rng(seed)
    sched = DEScheduler()
    net = Network(sched, N, rng=random.Random(seed + 1000))
    twin = DigitalTwin()
    proto = cls(sched, net, nodes, twin, rng=random.Random(seed + 2000))
    mal = {n.node_id for n in nodes if not n.honest}

    shares = []
    for t in range(N_SLOTS):
        twin.tick()
        sample_slot(nodes, t, np_rng)
        for n in nodes:
            twin.forecast(n)
        apply_attacks(nodes, np_rng, twin)
        for n in nodes:
            twin.record(n)
            if isinstance(proto, PoET2S):
                proto.update_trust(n)
        committee = proto._committee()
        shares.append(100.0 * sum(1 for c in committee if c in mal) / len(committee))
    return statistics.mean(shares)


def main() -> int:
    print(f"Committee infiltration: N={N}, {len(SEEDS)} seeds, {N_SLOTS} slots")
    print("Malicious population = 15.0% (the no-defence baseline)\n")

    rows = []
    for label, cls, adaptive in [
        ("PoMonitor", PoMonitor, False),
        ("PoET2S", PoET2S, False),
        ("PoMonitor-adaptive", PoMonitor, True),
        ("PoET2S-adaptive", PoET2S, True),
    ]:
        per_seed = [infiltration_share(cls, s, adaptive) for s in SEEDS]
        mean = statistics.mean(per_seed)
        sd = statistics.stdev(per_seed)
        print(f"  {label:20s} {mean:5.2f}% +/- {sd:4.2f}")
        for s, v in zip(SEEDS, per_seed):
            rows.append({"scheme": label, "seed": s, "mal_committee_pct": round(v, 3)})

    with open(OUTPUT_CSV, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["scheme", "seed", "mal_committee_pct"])
        w.writeheader()
        w.writerows(rows)

    # headline comparison
    pm = [r["mal_committee_pct"] for r in rows if r["scheme"] == "PoMonitor"]
    pe = [r["mal_committee_pct"] for r in rows if r["scheme"] == "PoET2S"]
    reduction = (1 - statistics.mean(pe) / statistics.mean(pm)) * 100
    wins = sum(1 for a, b in zip(pe, pm) if a < b)
    print(f"\nPoET2S reduces malicious committee share by {reduction:.0f}% "
          f"vs twin-as-veto ({wins}/{len(SEEDS)} seeds).")
    try:
        from scipy.stats import wilcoxon
        print(f"Wilcoxon p = {wilcoxon(pe, pm).pvalue:.4f}")
    except ImportError:
        pass

    print(f"\nWrote {OUTPUT_CSV}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
