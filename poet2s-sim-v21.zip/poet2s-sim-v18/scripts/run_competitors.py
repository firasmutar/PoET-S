"""Comparison against 2025-2026 twin-consensus mechanisms.

A single competitor (PoMonitor) is thin. This script compares PoET2S against
four faithful models of distinct mechanisms from the current literature, each
implemented inside our own simulator so the comparison is on equal footing
(same network, workload, seeds). The schemes differ in exactly how the twin /
trust signal enters validator selection:

  PoMonitor  - binary veto, unweighted survivors        (Weerasinghe 2023; 2025 PoM reuse)
  EACM       - additive energy+trust, linear, with floor (Sensors 2025 energy-aware consensus)
  RepStake   - reputation as a linear stake multiplier   (B-DT reputation-as-stake, 2024-25)
  PoET2S     - trust^gamma continuous weighting (gamma=2.5)   (this work)

The key comparison is RepStake vs PoET2S: RepStake is the gamma=1 ablation, so
any difference between them is attributable purely to the superlinear exponent.

We report detection (caught %, FP/caught) and committee infiltration (malicious
share of the validating committee). Detection is mixed across schemes;
infiltration is where the selection mechanism shows, and there the ordering is
monotonic in how aggressively each scheme weights trust.

Run from the repository root:
    python scripts/run_competitors.py
"""
from __future__ import annotations

import csv
import random
import statistics
import sys
from pathlib import Path

import numpy as np

from poet2s_sim.detection import run_protocol_slots
from poet2s_sim.grid_model import (
    DigitalTwin,
    apply_attacks,
    build_grid,
    sample_slot,
)
from poet2s_sim.protocols import CONSENSUS_CLASSES, PoET2S
from poet2s_sim.sim_core import DEScheduler, Network

REPO_ROOT = Path(__file__).resolve().parent.parent
RESULTS_DIR = REPO_ROOT / "results"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_CSV = RESULTS_DIR / "competitors.csv"

N = 500
N_SLOTS = 60
SEEDS = list(range(42, 52))
N_MAL = int(N * 0.15)
SCHEMES = ["PoMonitor", "EACM", "RepStake", "PoET2S"]
MECHANISM = {
    "PoMonitor": "binary veto, unweighted survivors",
    "EACM": "additive energy+trust, linear, floor",
    "RepStake": "reputation x stake (gamma=1)",
    "PoET2S": "trust^gamma weighting (gamma=2.5)",
}


def detection(scheme: str, seed: int):
    r = run_protocol_slots(scheme, n_nodes=N, seed=seed, n_slots=N_SLOTS)
    c = r[-1].attackers_caught
    return 100.0 * c / N_MAL, r[-1].false_pos_cum / max(c, 1)


def infiltration(scheme: str, seed: int) -> float:
    cls = CONSENSUS_CLASSES[scheme]
    rng = random.Random(seed)
    nodes = build_grid(N, 0.15, rng)
    np_rng = np.random.default_rng(seed)
    sched = DEScheduler()
    net = Network(sched, N, rng=random.Random(seed + 1000))
    twin = DigitalTwin()
    proto = cls(sched, net, nodes, twin, rng=random.Random(seed + 2000))
    mal = {n.node_id for n in nodes if not n.honest}
    shares = []
    for t in range(N_SLOTS):
        twin.tick()
        sample_slot(nodes, t, np_rng)
        for n in nodes:
            twin.forecast(n)
        apply_attacks(nodes, np_rng, twin)
        for n in nodes:
            twin.record(n)
            if isinstance(proto, PoET2S):
                proto.update_trust(n)
        committee = proto._committee()
        shares.append(100.0 * sum(1 for c in committee if c in mal) / len(committee))
    return statistics.mean(shares)


def main() -> int:
    print(f"2025-2026 competitor comparison: N={N}, {len(SEEDS)} seeds, {N_SLOTS} slots\n")
    data = {}
    rows = []
    print(f"{'scheme':10s} {'caught':>7s} {'FP/c':>7s} {'infil':>7s}   mechanism")
    for s in SCHEMES:
        caught, fpc, infil = [], [], []
        for seed in SEEDS:
            c, f = detection(s, seed)
            i = infiltration(s, seed)
            caught.append(c)
            fpc.append(f)
            infil.append(i)
            rows.append({"scheme": s, "seed": seed,
                         "caught_pct": round(c, 2),
                         "fp_per_caught": round(f, 2),
                         "infiltration_pct": round(i, 3)})
        data[s] = (caught, fpc, infil)
        print(f"{s:10s} {statistics.mean(caught):6.1f}% {statistics.mean(fpc):7.2f} "
              f"{statistics.mean(infil):6.2f}%   {MECHANISM[s]}")

    with open(OUTPUT_CSV, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["scheme", "seed", "caught_pct",
                                          "fp_per_caught", "infiltration_pct"])
        w.writeheader()
        w.writerows(rows)

    print("\n--- committee integrity: PoET2S vs each competitor ---")
    pe = data["PoET2S"][2]
    try:
        from scipy.stats import wilcoxon
        for s in ["PoMonitor", "EACM", "RepStake"]:
            other = data[s][2]
            wins = sum(1 for a, b in zip(pe, other) if a < b)
            p = wilcoxon(pe, other).pvalue
            red = (1 - statistics.mean(pe) / statistics.mean(other)) * 100
            print(f"  vs {s:10s}: {wins}/{len(SEEDS)} wins, p={p:.4f}, "
                  f"{red:.0f}% lower infiltration")
    except (ImportError, ValueError):
        pass

    print("\n  Key result: RepStake is the gamma=1 ablation of PoET2S. They share")
    print("  detection exactly, so the infiltration gap between them isolates the")
    print("  effect of the superlinear gamma=2.5 exponent on committee selection.")
    print(f"\nWrote {OUTPUT_CSV}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
